const esprima = require('esprima');
const fs = require('fs');
const path = require('path');

function countFunctions(ast) {
  let count = 0;

  function traverse(node) {
    if (!node) return;
    if (Array.isArray(node)) {
      node.forEach(traverse);
    } else if (typeof node === 'object') {
      try {
        if (
          ['FunctionDeclaration', 'FunctionExpression', 'ArrowFunctionExpression'].includes(node.type)
        ) {
          count++;
        }
        for (const key in node) {
          traverse(node[key]);
        }
      } catch (err) {
        console.warn(`⚠️ 노드 분석 중 오류 발생: ${err.message}`);
      }
    }
  }

  traverse(ast);
  return count;
}

const directoryPath = process.cwd();
const summary = [];

fs.readdir(directoryPath, (err, files) => {
  if (err) {
    console.error('❌ 디렉토리 읽기 실패:', err);
    return;
  }

  files.filter(file => file.endsWith('.js')).forEach(file => {
    console.log(`🔍 분석 중: ${file}`);
    const fullPath = path.join(directoryPath, file);
    const fileId = path.basename(file, '.js');
    let funcCount = -1;

    try {
      const code = fs.readFileSync(fullPath, 'utf8');
      let ast;

      try {
        ast = esprima.parseScript(code, { loc: true, range: true });
      } catch (e1) {
        try {
          ast = esprima.parseModule(code, { loc: true, range: true });
          console.warn(`ℹ️ ${file}: parseScript 실패 → parseModule 성공`);
        } catch (e2) {
          console.warn(`🚫 ${file}: 전체 파싱 실패 → 파일 건너뜀 (${e2.message})`);
          summary.push({ filename: fileId, functions: -1 });
          return;
        }
      }

      funcCount = countFunctions(ast);
      console.log(`✅ 함수 개수: ${funcCount}`);

      const outputFilename = fileId + '_ast.json';
      fs.writeFileSync(path.join(directoryPath, outputFilename), JSON.stringify(ast, null, 2));
      console.log(`💾 결과 저장: ${outputFilename}`);
    } catch (e) {
      console.error(`❌ 파일 ${file} 처리 중 예외 발생: ${e.message}`);
    }

    summary.push({ filename: fileId, functions: funcCount });
  });

  // CSV 저장
  const csvPath = path.join(directoryPath, 'function_count_summary.csv');
  const header = 'filename,functions\n';
  const rows = summary.map(row => `${row.filename},${row.functions}`).join('\n');

  fs.writeFileSync(csvPath, header + rows);
  console.log(`📄 CSV 저장 완료: ${csvPath}`);
});
